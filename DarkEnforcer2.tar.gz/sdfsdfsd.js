// Get the button element by its ID
const redirectButton = document.getElementById('redirectButton');

// Add a click event listener to the button
redirectButton.addEventListener('click', function() {
  // Display an alert message
  alert('Dark mode has been enabled!');
});
