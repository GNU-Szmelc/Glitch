# DARKMODE ENFORCER PLUGIN v1

- Obese Lord, I have good and bad news.
- Start with the bad one.
- Did not work.
- Hmm, what's good?
- We built it!
- FINALLY!!! Muahah
